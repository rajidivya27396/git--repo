
const fs = require('fs');
const readline = require('readline');
const {google} = require('googleapis');
const express = require('express');
const fetch = require('node-fetch');
const { checkServerIdentity } = require('tls');
const PORT = process.env.PORT || 3000;
const bodyParser = require("body-parser");
const util = require('util');

/**
* CONSTANTS
*/
var MESSAGE_INVITE = "To start creating virtul meet, type reserve (i.e *@Meetup reserve*)";
var GMT = ' GMT+0530';
var SHEET_ID = "https://docs.google.com/spreadsheets/d/1sYUh1aOR4cGvliPPdRyuFjfiM7DT6cTfYCq3-D-031U/edit?usp=sharing";
var MEET_TYPE = "hangoutsMeet";
var REQUEST_ID = "7qxalsvy0e";
var IMAGE_URL = "https://rajidivya-aws-bucket.s3.us-east-2.amazonaws.com/img";
var IMAGE_EXTENSION = ".jpg";
var MESSAGE_FORMAT = "Kindly fill meeting details in below format \n>>> *[ Summary ]* :: *[ Description ]* :: *[ StartDate-EndDate ]* <<<\n*eg : [Lunch]* :: *[Invitation for lunch meet]* :: *[August 15, 2021 21:00:00-August 15, 2021 22:00:00]*\nEnter *help* for more keywords"; 
var BOT_NAME = "@Meetup ";
var INFO = "<b>TIPS</b>\nType <b>reserve</b> to initiate lunch meet \nType <b>board</b> to participate in meet \nType <b>getoff</b> to leave \nType <b>cancel</b> to cancel lunch train by admin/owner";
var THREAD_PATTERN = /(spaces\/)(.*)(\/threads\/)(.*)/;
var CONFERENCE_VERSION = "conferenceDataVersion";
var NEW_MESSAGE = "NEW_MESSAGE";
var DETAIL_LEN = 3;
var NOT_ACCESS_API = -1;
var UPDATE_MESSAGE = "UPDATE_MESSAGE";
var COLOR_CODE = { INFO:'#3691ED',WARN:'#FF3933',HELP:'#7c9483' };
var RANDOM_NO = Math.floor((Math.random()*10)%4);
var ACTION = { BOARD:'board-train',GETOFF:'getoff-train',VIEW:'view-train',HELP:'help',CANCEL:'cancel-train' };
var MESSAGES = { BOARD:"%s added\nNo of Guests: %d",NOT_BOARD:"%s already added in meet",GETOFF:"%s left\nNo of Guests: %d",NOT_GETOFF:"Participant with the name %s does not exist",VIEW:"No of Guests: %d",NOT_VIEW:"No guests found\nNo of Guests: 0",CANCEL:"!!! Meeting has been cancelled !!!\n",CANCEL_MSG:"!!! Enter reserve to create new event !!!" };
var TEXT = { BOARD:'BOARD',GETOFF:'GETOFF',VIEW:'VIEW',HELP:'HELP',CANCEL:'CANCEL' }
var MEET_CREATED_USER = "Meet created by ";
var TITLE = "Lets Make Virtual Team Lunch";
var VIEW_MSG = 'Participants of event created by %s are\n';
var HTML_TAG = "<font color=%s>%s</font>";
var DOUBLE_FORMAT = "%s%s";
var ACCESS_DENIED = "Access Denied";
var METHOD_TYPE = {POST:'post',PATCH:'patch',GET:'get'};
const SCOPES = ['https://www.googleapis.com/auth/calendar','https://www.googleapis.com/auth/calendar.events'];
var getURL = "https://www.googleapis.com/calendar/v3/calendars/rajalakshmi.subbiah@ideas2it.com/events/";
const TOKEN_PATH = 'token.json';

const app = express()
    .use(express.urlencoded({extended: false}))
    .use(bodyParser.json());
/**
app.get("/", (req,res)=>{
  
var auth = authorize(JSON.parse(content),createEventCalendar,userMessage, req.body.message.thread.name, req.body.user.email, req.body.user.displayName,res);
//authorize(JSON.parse(content),createEventCalendar,userMessage, req.body.message.thread.name, req.body.user.email, req.body.user.displayName,res);
console.log(util.format("hi %s","name")); 
}); **/

app.post('/', (req, res) => {
  let text = '';
  // Case 1: When BOT was added to the ROOM
  if (req.body.type === 'ADDED_TO_SPACE' && req.body.space.type === 'ROOM') {
    text = `Thanks for adding me to ${req.body.space.displayName}`;
  // Case 2: When BOT was added to a DM
  } else if (req.body.type === 'ADDED_TO_SPACE' &&
      req.body.space.type === 'DM') {
    text = `Thanks for adding me to a DM, ${req.body.user.displayName}`;
  // Case 3: Texting the BOT
  } else if (req.body.type === 'MESSAGE') {
    var eventId;
    var len = BOT_NAME.length;
    var userMessage = req.body.message.text;
    if (userMessage.substring(len) == "reserve") {
      text = MESSAGE_FORMAT;

    } else if (userMessage.substring(len) == "help") {
      text = INFO;
      
    } else if (userMessage.substring(len) == "cancel") {
      //return { text:"cancelled" }

    } else if (userMessage.indexOf("[") != -1 && userMessage.split("::").length == DETAIL_LEN) {
      
      fs.readFile('credentials.json', (err, content) => {
        if (err) return console.log('Error loading client secret file:', err);
        authorize(JSON.parse(content), userMessage, req.body.user.displayName, 1, createEvent, cardResponse, function(response) {
        res.send(response);
        });
      });
      console.log(eventId);
    //  res.send(cardResponse(true, eventId, req.body.user.displayName, "rajalakshmi.subbiah@ideas2it.com"));
    
   }
  } else if (req.body.type === 'CARD_CLICKED') {
    var userName = req.body.user.displayName;
    var eventId = req.body.action.parameters[0].value;
    var mailId = req.body.user.email;
    var msg='';
    var createdUser = req.body.action.parameters[1].value;
    var organizerMailId = req.body.action.parameters[2].value;
    var methodName = req.body.action.actionMethodName;
    var attendeesCount = 0;
    var info = req.body;
    console.log("started");
    console.log(info);
    console.log(eventId);
    // return res.send({text:"created"});
      if (methodName == ACTION.BOARD) {
        fs.readFile('credentials.json', (err, content) => {
          if (err) return console.log('Error loading client secret file:', err);
          authorizeAddToEvent(JSON.parse(content), createdUser, mailId, organizerMailId, eventId,methodName,userName, 2, addToEvent, cardResponse, function(response) {
          res.send(response);
          });
        });
       // attendeesCount = authorize(addToEvent, mailId, organizerMailId, eventId));
        //return res.send({text:attendeesCount});
      } else if (methodName == ACTION.GETOFF) {
        fs.readFile('credentials.json', (err, content) => {
          if (err) return console.log('Error loading client secret file:', err);
          authorizeGetOff(JSON.parse(content), createdUser, mailId, organizerMailId, eventId,methodName,userName, 3, getOffEvent, cardResponse, function(response) {
          res.send(response);
          });
        });
       // attendeesCount = getOffEvent(mailId,organizerMailId,eventId);
      
      } else if (methodName == ACTION.CANCEL) {
        fs.readFile('credentials.json', (err, content) => {
          if (err) return console.log('Error loading client secret file:', err);
          authorizeCancel(JSON.parse(content), userMessage, req.body.user.displayName, createEvent, cardResponse, function(response) {
          res.send(response);
          });
        });
        attendeesCount = cancelEvent(eventId,organizerMailId,createdUser,userName)
    
        if (attendeesCount == NOT_ACCESS_API)
        eventId = NOT_ACCESS_API;
    
      } else if (methodName == ACTION.VIEW) {
        fs.readFile('credentials.json', (err, content) => {
          if (err) return console.log('Error loading client secret file:', err);
          authorizeView(JSON.parse(content), userMessage, req.body.user.displayName, createEvent, cardResponse, function(response) {
          res.send(response);
          });
        });
        msg = showMembers(eventId,organizerMailId,createdUser);
        if (msg != NOT_ACCESS_API)
        return { text:msg };
      }
    //  if( attendeesCount == undefined) {
    //    return showConfigure(getcalendarService().getAuthorizationUrl());
    //  } else {
      //  res.send(cardResponse(false, eventId, createdUser, organizerMailId, methodName, userName, attendeesCount));
     // }
  }
  
 // return res.json({text});
});

/**
fs.readFile('credentials.json', (err, content) => {
  if (err) return console.log('Error loading client secret file:', err);
  var eventId;
  // Authorize a client with credentials, then call the Google Calendar API.
 authorize(JSON.parse(content),createEventCalendar,"lunch");

// eventId = createEventCalendar(autho,"lunch");
  //console.log("event-id:"+eventId);
});

**/
// Load client secrets from a local file.
/** 
 * Create an OAuth2 client with the given credentials, and then execute the
 * given callback function.
 * @param {Object} credentials The authorization client credentials.
 * @param {function} callback The callback to call with the authorized client.
 */
function authorize(credentials, userMessage, createdUser, flag, callback, callCardResponse, responseCall) {
  const {client_secret, client_id, redirect_uris} = credentials.installed;
  const oAuth2Client = new google.auth.OAuth2(
      client_id, client_secret, redirect_uris[0]);

  // Check if we have previously stored a token.
  fs.readFile(TOKEN_PATH, (err, token) => {
    if (err) return getAccessToken(oAuth2Client, userMessage, threadName, organizerMailId, createdUser, res);
    oAuth2Client.setCredentials(JSON.parse(token));
    if(flag == 1)
    callback(oAuth2Client, userMessage, createdUser, callCardResponse, responseCall);
    else if(flag == 2)
    callback(oAuth2Client, mailId, organizerMailId, eventId, callCardResponse, responseCall); 
  });
}

function authorizeAddToEvent(credentials, createdUser, mailId, organizerMailId, eventId, methodName, userName, flag, callback, callCardResponse, responseCall) {
  const {client_secret, client_id, redirect_uris} = credentials.installed;
  const oAuth2Client = new google.auth.OAuth2(
      client_id, client_secret, redirect_uris[0]);

  // Check if we have previously stored a token.
  fs.readFile(TOKEN_PATH, (err, token) => {
    if (err) return getAccessToken(oAuth2Client, userMessage, threadName, organizerMailId, createdUser, res);
    oAuth2Client.setCredentials(JSON.parse(token));
    console.log("credential");
    if (flag == 2)
    callback(oAuth2Client, createdUser, mailId, organizerMailId, eventId, methodName, userName, callCardResponse, responseCall);
    if (flag == 3)
    callback(oAuth2Client, createdUser, mailId, organizerMailId, eventId, methodName, userName, callCardResponse, responseCall);
  });
}

/**
 * Get and store new token after prompting for user authorization, and then
 * execute the given callback with the authorized OAuth2 client.
 * @param {google.auth.OAuth2} oAuth2Client The OAuth2 client to get token for.
 * @param {getEventsCallback} callback The callback for the authorized client.
 */

function getAccessToken(oAuth2Client, callback, userMessage, threadName, organizerMailId, createdUser, res) {
  const authUrl = oAuth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: SCOPES,
    login_hint: 'rajalakshmi.subbiah@ideas2it.com'
  });
  console.log('Authorize this app by visiting this url:', authUrl);
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  rl.question('Enter the code from that page here: ', (code) => {
    rl.close();
    oAuth2Client.getToken(code, (err, token) => {
      if (err) return console.error('Error retrieving access token', err);
      oAuth2Client.setCredentials(token);
      // Store the token to disk for later program executions
      fs.writeFile(TOKEN_PATH, JSON.stringify(token), (err) => {
        if (err) return console.error(err);
        console.log('Token stored to', TOKEN_PATH);
      });
      
    callback(oAuth2Client, userMessage, threadName, organizerMailId, createdUser, res , cardResponse);
    });
  });
}

/**
* To create event in calendar
*/
async function createEvent(auth ,userMessage, createdUser, callCardResponse, responseCall) {
  //var spaceID = THREAD_PATTERN.exec(threadName)[2];
  //var threadID = THREAD_PATTERN.exec(threadName)[4];
  var len = BOT_NAME.length;
  var data = userMessage.substring(len).split("::");
  var startDate = new Date(data[2].substring(1, data[2].length-1).split("-")[0] + GMT);
  var endDate =   new Date(data[2].substring(1, data[2].length-1).split("-")[1] + GMT);
  //var sheetApp = SpreadsheetApp.openByUrl(SHEET_ID);
  //var sheet = sheetApp.getSheets()[0];
  const calendar = google.calendar({version: 'v3', auth});
  calendar.events.insert({
  conferenceDataVersion: 1,
  sendNotifications: true,
  calendarId: 'rajalakshmi.subbiah@ideas2it.com',
  resource: { 
  summary: data[0].substring(1, data[0].length - 1),
  description: data[1].substring(1, data[1].length - 1),
  start: {
    dateTime: startDate.toISOString()
  },
  end: {
    dateTime: endDate.toISOString()
  },
  attendees: [],
  conferenceData: {
        createRequest: {
          conferenceSolutionKey: {
            type: "hangoutsMeet"
          },
          requestId: "7qxalsvy0e",
        }
      }
    },
   
  }).then(function(response) {
    callCardResponse(true, response.data.id , createdUser, 'rajalakshmi.subbiah@ideas2it.com', null, null, null, function(response) {
    return responseCall(response);
    });
      
    
  }, function(err) {
    console.log(`error occurs, ${err}`);
    //callback(true, "id" ,createdUser, organizerMailId,res);
  });
}

/**
* Responds to GETOFF button click
*/
function getOffEvent(auth, createdUser, mailId, organizerMailId, eventId, methodName, userName, callCardResponse, responseCall) {
  var attendeesCount = NOT_ACCESS_API;
  var removed = false;
  var remAttendees = [];
  var calendarEvent;
  var calendar = google.calendar({version: 'v3', auth});
  

 calendar.events.get({"calendarId": "rajalakshmi.subbiah@ideas2it.com", "eventId": eventId}).then(function(response) {
 calendarEvent = response;
  if (calendarEvent.attendees != undefined) {
    for (var i = 0; i < calendarEvent.attendees.length; i++) {
      if (calendarEvent.attendees[i].email == mailId) {
        calendarEvent.attendees.pop();
        removed = true;
      }  
    }
  }

  if (removed) {
  calendar.events.patch({"resource": {"attendees": calendarEvent.attendees}, "calendarId": "rajalakshmi.subbiah@ideas2it.com", "eventId": eventId}, {sendNotifications: true});
  return attendeesCount;
    }
  }).then(function(response) {
    callCardResponse(false, eventId, createdUser, organizerMailId, methodName, userName, response, function(response) {
    return responseCall(response);
    });
  });
 }
  
function createEventCalendar(auth,a,callback) {
  const calendar = google.calendar({version: 'v3', auth});
  var eventId;
  console.log("started");
  var startDate = new Date("August 19, 2021 21:00:00"+GMT);
  var endDate = new Date("August 19, 2021 22:00:00"+GMT);
  //var servicecheck = getcalendarService();
  calendar.events.insert({
  conferenceDataVersion: 1,
  sendNotifications: true,
  calendarId: 'primary',
  resource: { 
  summary: a,
  description: "description",
  start: {
    dateTime: startDate.toISOString()
  },
  end: {
    dateTime: endDate.toISOString()
  },
  attendees: [],
  conferenceData: {
        createRequest: {
          conferenceSolutionKey: {
            type: "hangoutsMeet"
          },
          requestId: "7qxalsvy0e",
        }
      }
    }
   
  }).then(function(response) {
    console.log("started1"+response.data);
    return response.data.id;
   // callback(response.data.id)
    //return response.data.id;
    
  },function(err) {
    console.log("started2");
    console.log(`error occurs,${err}`);
    return -1;
  });
}



function check(res) {
 res.send("check");
}
app.listen(PORT , () =>{
console.log("running");
});

/**
* WIDGET
*/
function viewMember(info) {
  var widget = [{textParagraph: {text: util.format("%s",info)}}];
  return { widgets: widget };
  }
  
  /**
  * WIDGET
  */
  function imagePanel() {
  var widget = [{image: {imageUrl: util.format(DOUBLE_FORMAT,IMAGE_URL+RANDOM_NO,IMAGE_EXTENSION)}}];
  return { widgets:widget };
  }
  
  /**
  * WIDGET
  */
  function buttonwidget( id,createdUser,mailid ) {
  var widget = [              
    {
      buttons: [
        {
          textButton: {
            text: TEXT.BOARD,
            onClick: {
              action: {
                actionMethodName: ACTION.BOARD,
                parameters: [
                  {
                     key: "id",
                     value: id
                  },
                  {
                     key: "created",
                     value: createdUser
                  },
                  {
                     key: "mailid",
                     value: mailid
                  }
                ]
              }
            }
          }
        },
        {
           textButton: {
            
             text: TEXT.GETOFF,
             onClick: {
               action: {
                 actionMethodName: ACTION.GETOFF,
                 parameters: [
                  {
                     key: "id",
                     value: id
                  },
                  {
                     key: "created",
                     value: createdUser
                  },
                  {
                     key: "mailid",
                     value: mailid
                  }
                ]
              }
            }
          }
        },
        {
          
           textButton: {
            
             text: TEXT.VIEW,
             onClick: {
               action: {
                 actionMethodName: ACTION.VIEW,
                 parameters: [
                  {
                     key: "id",
                     value: id
                  },
                  {
                     key: "created",
                     value: createdUser
                  },
                  {
                     key: "mailid",
                     value: mailid
                  }
                ]
              }
            }
          }
        },
        {
          
           textButton : {
            
             text: TEXT.HELP,
             onClick: {
               action: {
                actionMethodName: ACTION.HELP,
                parameters: [
                  {
                     key: "id",
                     value: id
                  },
                  {
                     key: "created",
                     value: createdUser
                  },
                  {
                     key: "mailid",
                     value: mailid
                  }
                ]
              }
            }
          }
        },
        {
           textButton: {
             text: TEXT.CANCEL,
             onClick: {
               action: {
                actionMethodName: ACTION.CANCEL,
                parameters: [
                  {
                     key: "id",
                     value: id
                  },
                  {
                     key: "created",
                     value: createdUser
                  },
                  {
                     key: "mailid",
                     value: mailid
                  }
                ]
              }
            }
          }
        },
      ]
    }];
      
  return { widgets: widget };
  }
  
  
/**
* Responds to BOARD button click
*/
function addToEvent(auth, createdUser, mailId, organizerMailId, eventId, methodName, userName, callCardResponse, responseCall) {
  var calendarEvent;
  var attendeesCount;
  var calendar = google.calendar({version: 'v3', auth});
  

  calendar.events.get({"calendarId": "rajalakshmi.subbiah@ideas2it.com", "eventId": eventId}).then(function(response) {
    
  /** console.log(calendarEvent);
  
  //console.log(calendarEvent);
  //Logger.log(calendarEvent.attendees);
 // console.log(calendarEvent);
  if (calendarEvent.attendees != undefined) {
    attendeesCount = calendarEvent.attendees.length;
    for (var i = 0; i < attendeesCount; i++) {
      if (calendarEvent.attendees[i].email == mailId)
        return NOT_ACCESS_API;
    }
    calendarEvent.attendees.push({
      email: mailId
    });
    attendeesCount = attendeesCount + 1;
  } else {
    calendarEvent.attendees = new Array({ email : mailId});
    attendeesCount = calendarEvent.attendees.length; 
  }
  console.log("push");
console.log("count "+attendeesCount);**/ 
  calendarEvent = response;
  
  if (calendarEvent.attendees != undefined) {
    attendeesCount = calendarEvent.attendees.length;
    for (var i = 0; i < attendeesCount; i++) {
      if (calendarEvent.attendees[i].email == mailId)
      attendeesCount = NOT_ACCESS_API;
    }
    calendarEvent.attendees.push({
      email: mailId
    });
    attendeesCount = attendeesCount + 1;
  } else {
    calendarEvent.attendees = new Array({ email : mailId});
    attendeesCount = calendarEvent.attendees.length; 
  }
  console.log("push");
  console.log("count "+attendeesCount);

  calendar.events.patch({"resource": {"attendees": calendarEvent.attendees}, "calendarId": "rajalakshmi.subbiah@ideas2it.com", "eventId": eventId}, {sendNotifications: true});
  return attendeesCount;
 }).then(function(response) {
    callCardResponse(false, eventId, createdUser, organizerMailId, methodName, userName, response, function(response) {
      return responseCall(response);
});
});
}  

  /**
  * CARD_CREATION
  */
  function cardResponse(responseType, eventId, createdUser, mailId, methodName, userName, attendeesCount, callback) {
  var section = [];
  var message = '';
  section.push(imagePanel());
  
  if (!responseType && eventId != NOT_ACCESS_API) {
    if (methodName == ACTION.BOARD) {
      if( attendeesCount != NOT_ACCESS_API )
      message = responseText(util.format(MESSAGES.BOARD,userName,attendeesCount),COLOR_CODE.INFO);
      else
      message = responseText(util.format(MESSAGES.NOT_BOARD,userName),COLOR_CODE.INFO);
  
    } else if (methodName == ACTION.GETOFF) {
      if( attendeesCount != NOT_ACCESS_API )
      message = responseText(util.format(MESSAGES.GETOFF,userName,attendeesCount),COLOR_CODE.WARN);
      else
      message = responseText(util.format(MESSAGES.NOT_GETOFF,userName),COLOR_CODE.WARN);
  
    } else if (methodName == ACTION.VIEW) {
      if (attendeesCount != NOT_ACCESS_API)
      message = responseText(util.format(MESSAGES.VIEW,attendeesCount),COLOR_CODE.INFO);
      else
      message = responseText(util.format(MESSAGES.NOT_VIEW),COLOR_CODE.INFO);
  
    } else if (methodName == ACTION.HELP) {
      message = responseText(util.format("%s",INFO),COLOR_CODE.HELP);
  
    } else if (methodName == ACTION.CANCEL) { 
      message = responseText(util.format("%s",ACCESS_DENIED),COLOR_CODE.INFO);
    }
    section.push(viewMember(message));
   }
  
  if (methodName == ACTION.CANCEL && eventId == NOT_ACCESS_API) {
    section.push(viewMember(util.format(DOUBLE_FORMAT,responseText(util.format(MESSAGES.CANCEL),COLOR_CODE.WARN),responseText(util.format(MESSAGES.CANCEL_MSG),COLOR_CODE.INFO))));
  }
  if (eventId != NOT_ACCESS_API)  
    section.push(buttonwidget(eventId, createdUser, mailId));
    return callback({ 
      actionResponse: { type: (responseType) ? NEW_MESSAGE:UPDATE_MESSAGE },
      cards: [{
        header: { title: TITLE, subtitle : util.format(DOUBLE_FORMAT,MEET_CREATED_USER,createdUser), imageUrl :util.format(DOUBLE_FORMAT,IMAGE_URL,IMAGE_EXTENSION) },
        sections: section
      }]
    });
  }
  
  /**
   * Response texts for each action performed
   */
  function responseText(message,color) {
  return util.format(HTML_TAG,color,message);
  }
  
  


/**
 * Lists the next 10 events on the user's primary calendar.
 * @param {google.auth.OAuth2} auth An authorized OAuth2 client.
 */

function listEvents(auth) {
  const calendar = google.calendar({version: 'v3', auth});
  calendar.events.list({
    calendarId: 'primary',
    timeMin: (new Date()).toISOString(),
    maxResults: 10,
    singleEvents: true,
    orderBy: 'startTime',
  }, (err, res) => {
    if (err) return console.log('The API returned an error: ' + err);
    const events = res.data.items;
    if (events.length) {
      console.log('Upcoming 10 events:');
      events.map((event, i) => {
        const start = event.start.dateTime || event.start.date;
        console.log(`${start} - ${event.summary}`);
      });
    } else {
      console.log('No upcoming events found.');
    }
  });
}
