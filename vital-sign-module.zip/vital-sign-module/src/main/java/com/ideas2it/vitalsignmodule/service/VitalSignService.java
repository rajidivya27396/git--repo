package com.ideas2it.vitalsignmodule.service;

import java.util.Optional;

import com.ideas2it.vitalsignmodule.dto.VitalSignDto;
import com.ideas2it.vitalsignmodule.entity.ReportClass;

public interface VitalSignService {
	VitalSignDto saveVitalSign(VitalSignDto vitalsign, long id);
	VitalSignDto getVitalSign(long id);
	Optional<ReportClass> getReport(long id);
}
