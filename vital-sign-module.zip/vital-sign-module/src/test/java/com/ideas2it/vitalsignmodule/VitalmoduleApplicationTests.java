package com.ideas2it.vitalsignmodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VitalmoduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
