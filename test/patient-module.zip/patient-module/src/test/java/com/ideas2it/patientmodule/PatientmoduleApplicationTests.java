package com.ideas2it.patientmodule;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
//import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ideas2it.patientmodule.controller.PatientController;
import com.ideas2it.patientmodule.dto.PatientDto;
import com.ideas2it.patientmodule.entity.Address;
import com.ideas2it.patientmodule.entity.Patient;
import com.ideas2it.patientmodule.repository.PatientRepository;
import com.ideas2it.patientmodule.serviceimpl.PatientServiceImpl;
import com.sun.tools.javac.util.Assert;

@RunWith(SpringRunner.class)
@SpringBootTest
//@WebMvcTest(PatientController.class)
public class PatientmoduleApplicationTests {

	@MockBean
	private PatientRepository patientRepo;
	@InjectMocks
	private PatientServiceImpl service;
	@Autowired
	private WebApplicationContext context;
	//@MockBean
    private MockMvc mockMvc;

	
    @BeforeEach
	public void setUp() throws ParseException {
		Address address = new Address();
		Patient patient = new Patient(8,"raji","sp","female",24,false,new SimpleDateFormat("yyyy-MM-dd").parse("2020-10-03"),"9677980214","ram","9567898234","brother","GK",address);
		PatientDto patientDto = new PatientDto();
		patientDto.setAddress(patient.getAddress());
		patientDto.setPatientId(patient.getPatientId());
		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
		Mockito.when(patientRepo.save(patient))
	      .thenReturn(patient);
		service = new PatientServiceImpl(patientRepo);
	}
	
	@Test
	public void savePatient() throws ParseException {
		Address address = new Address();
		Patient patient = new Patient(8,"raji","sp","female",24,false,new SimpleDateFormat("yyyy-MM-dd").parse("2020-10-03"),"9677980214","ram","9567898234","brother","GK",address);
		PatientDto patientDto = PatientDto.entityToDto(patient);
		//patientDto.setAddress(patient.getAddress());
		//patientDto.setPatientId(patient.getPatientId());
		when(service.savePatient(patientDto)).thenReturn(patientDto);
        		//.thenReturn(PatientDto.entityToDto(patient));
		Assert.check(patientDto.getPatientId()==8);
    }
 
     @Test
     public void getUserByName() throws ParseException {
    	long id = 8;
    	Address address = new Address();
		Optional<Patient> patient = Optional.of(new Patient(8,"raji","sp","female",24,false,new SimpleDateFormat("yyyy-MM-dd").parse("2020-10-03"),"9677980214","ram","9567898234","brother","GK",address));
		//Optional<PatientDto> patientDto = Optional.of(PatientDto.entityToDto(patient.get()));
		when(patientRepo.findById(id)).thenReturn(patient);
    	//PatientDto patient_Dto = service.getPatientById(id); 
    	Assert.check(patient.get().getPatientId()==8);
    }
				
     @Test           
	 public void updateUser() throws ParseException {
    	Address address=new Address();
 		Patient patient =new Patient(8,"raji","sp","female",24,false,new SimpleDateFormat("yyyy-MM-dd").parse("2020-10-03"),"9677980214","ram","9567898234","brother","GK",address);
 		PatientDto patientDto = PatientDto.entityToDto(patient);
 		when(service.updatePatient(patientDto)).thenReturn(patientDto);
        Assert.check(patient.getPatientId()==8);
    }
     /**
      * Tests for controller
      * @throws Exception
      */
     
 /**    @Test
	 public void addUser() throws Exception {
    	ObjectMapper obj = new ObjectMapper();
    	Address address = new Address();
    	PatientDto patient = new PatientDto(1,"raji","sp","female",24,false,new SimpleDateFormat("yyyy-MM-dd").parse("2020-10-03"),"9677980214","ram","9567898234","brother","GK",address,null,null,null,null);
        String jsonString = obj.writeValueAsString(patient);
        mockMvc.perform(
        		MockMvcRequestBuilders.post("/patients/register").content(jsonString).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.firstname").value("raji"));
       // Assert.assertTrue(response.getPatientId()==1);
       
    }
     
     @Test
	 public void modifyUser() throws Exception {
    	ObjectMapper obj = new ObjectMapper();
    	Address address = new Address();
    	Patient patient = new Patient(1,"raji","sp","female",24,false,new SimpleDateFormat("yyyy-MM-dd").parse("2020-10-03"),"9677980214","ram","9567898234","brother","GK",address);
        String jsonString = obj.writeValueAsString(patient);
        mockMvc.perform(MockMvcRequestBuilders.put("/patients/update").content(jsonString).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isCreated()).andExpect(MockMvcResultMatchers.jsonPath("$.firstname").value("raji"));

       // Assert.assertTrue(response.getPatientId()==1);
       
    }**/
 
}
