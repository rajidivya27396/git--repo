import 'primeicons/primeicons.css';
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.css';
//import 'primeflex/primeflex.css';
//import '../../index.css';
import React, { useState, useEffect, useRef } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
//import ProductService from '../service/ProductService';
import { Rating } from 'primereact/rating';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import AuditService from '../services/AuditService';
import '../DataTableDemo.css';

const DataTableRowExpansionDemo = () => {
    const [auditEvents, setAuditEvents] = useState([]);
    const [expandedRows, setExpandedRows] = useState(null);
    const toast = useRef(null);
    const isMounted = useRef(false);
    //const productService = new ProductService();

    useEffect(() => {
        if (isMounted.current) {
          //  const summary = expandedRows !== null ? 'All Rows Expanded' : 'All Rows Collapsed';
            // toast.current.show({severity: 'success', summary: `${summary}`, life: 3000});
        }
    }, [expandedRows]);

    useEffect(() => {
        isMounted.current = true;
        AuditService.getAuditEvents().then(response => setAuditEvents(response.data));
    }, []); // eslint-disable-line react-hooks/exhaustive-deps

    const onRowExpand = (event) => {
        toast.current.show({severity: 'info', summary: 'Product Expanded', detail: event.data.transaction_code, life: 3000});
    }

    const onRowCollapse = (event) => {
        toast.current.show({severity: 'success', summary: 'Product Collapsed', detail: event.data.transaction_code, life: 3000});
    }

    const expandAll = () => {
        let _expandedRows = {};
        auditEvents.forEach(p => _expandedRows[`${p.transaction_code}`] = true);

        setExpandedRows(_expandedRows);
    }

    const collapseAll = () => {
        setExpandedRows(null);
    }
/** 
    const formatCurrency = (value) => {
        return value.toLocaleString('en-US', {style: 'currency', currency: 'USD'});
    }

    const amountBodyTemplate = (rowData) => {
        return formatCurrency(rowData.amount);
    }

    const statusOrderBodyTemplate = (rowData) => {
        return <span className={`order-badge order-${rowData.status.toLowerCase()}`}>{rowData.status}</span>;
    }

    const searchBodyTemplate = () => {
        return <Button icon="pi pi-search" />;
    }

    const imageBodyTemplate = (rowData) => {
        return <img src={`showcase/demo/images/product/${rowData.image}`} onError={(e) => e.target.src='https://www.primefaces.org/wp-content/uploads/2020/05/placeholder.png'} alt={rowData.image} className="product-image" />;
    }

    const priceBodyTemplate = (rowData) => {
        return formatCurrency(rowData.price);
    }

    const ratingBodyTemplate = (rowData) => {
        return <Rating value={rowData.rating} readonly cancel={false} />;
    }

    const statusBodyTemplate = (rowData) => {
        return <span className={`product-badge status-${rowData.inventoryStatus.toLowerCase()}`}>{rowData.inventoryStatus}</span>;
    }
**/
const header = (
    <div className="table-header-container">
     <h5>Audit Events </h5>
    </div>
);

    const rowExpansionTemplate = (data) => {
     
      if(data.api==="User API") {
        column_value = (<div>
            <h5>Old Data</h5>
            <table className = "table table-striped">
              <thead>
                  <tr>
                      <td>User Name</td>
                      <td>{data.oldData.username}</td>
                  </tr>
                  <tr>
                      <td>Password</td>
                      <td>{data.oldData.password}</td>
                  </tr>
                  <tr>
                      <td>Email</td>
                      <td>{data.oldData.email}</td>
                  </tr>
                </thead>   
               </table>
               <h5>Updated Data</h5>
            <table className = "table table-striped">
              <thead>
                  <tr>
                      <td>User Name</td>
                      <td>{data.updatedData.username}</td>
                  </tr>
                  <tr>
                      <td>Password</td>
                      <td>{data.updatedData.password}</td>
                  </tr>
                  <tr>
                      <td>Email</td>
                      <td>{data.updatedData.email}</td>
                  </tr>
                </thead>   
               </table>
       </div>
       ); 
    }
    if(data.api==="Patient API") {
      column_value = ( 
        <div>
            <h5>Old Data</h5>
            <table className = "table table-striped">
              <thead>
                  <tr>
                      <td>Patient</td>
                      <td>{data.oldData.username}</td>
                  </tr>
                  <tr>
                      <td>Password</td>
                      <td>{data.oldData.password}</td>
                  </tr>
                  <tr>
                      <td>Email</td>
                      <td>{data.oldData.email}</td>
                  </tr>
                </thead>   
               </table>
               <h5>Updated Data</h5>
            <table className = "table table-striped">
              <thead>
                  <tr>
                      <td>User Name</td>
                      <td>{data.updatedData.username}</td>
                  </tr>
                  <tr>
                      <td>Password</td>
                      <td>{data.updatedData.password}</td>
                  </tr>
                  <tr>
                      <td>Email</td>
                      <td>{data.updatedData.email}</td>
                  </tr>
                </thead>   
               </table>
       </div>
        
        
     ); 
  }
  if(data.api==="Vital API") {
    column_value = (<div>
       <h5>History Old  {data.objectId}</h5>
       <DataTable value={data.oldData}>
          <Column field="username" header="Username" sortable></Column>
          <Column field="password" header="Password" sortable></Column>
       </DataTable>
       <h5>History new  {data.transactionCode}</h5>
       <DataTable value={data.updatedData}>
          <Column field={data.updatedData.username} header="Username" sortable></Column>
          <Column field={data.updatedData.password} header="Password" sortable></Column>
       </DataTable>
     </div>
   ); 
}
        return (
            <div className="orders-subtable">
        {column_value}
            </div>
        );
    }

    return (
        <div className="datatable-rowexpansion-demo">
            <Toast ref={toast} />

            <div className="card">
                <DataTable value={auditEvents} expandedRows={expandedRows} onRowToggle={(e) => setExpandedRows(e.data)}
                    rowExpansionTemplate={rowExpansionTemplate} dataKey="transactionCode" header={header} expander>
                    <Column expander style={{ width: '1em' }} />
                    <Column field="transactionCode" header="Id" sortable />
                    <Column field="entityName" header="Entity Name" sortable />
                    <Column field="methodName" header="Method Name" sortable />
                    <Column field="methodType" header="Method Type" sortable />
                    <Column field="objectId" header="Object Id" sortable />
                   
                    <Column field="api" header="Api" sortable />
                </DataTable>
            </div>
        </div>
    );
}

export default DataTableRowExpansionDemo;