import React from 'react';
import MaterialTable from 'material-table';
import AuditService from '../services/AuditService';
import '../index.css';

class AuditComponent extends React.Component {
    constructor(props) {
    super(props);
    this.state = {
           events:[]
       }
    }

    componentDidMount() {
        AuditService.getAuditEvents().then((response) => {
            this.setState({events:response.data})
        });
        
    }
    render() {
        const column = [{title:'Transation Id',field:'transactionCode'},
        {title:'Entity Name',field:'entityName'},
        {title:'User',field:'userCode'},
        {title:'Object Id',field:'objectId'},
        {title:'Method Type',field:'methodType'},
        {title:'Old Data',field:'oldData'},
        {title:'Updated Data',field:'updatedData'},
        {title:'Changed Date',field:'changedDate'},
        {title:'API',field:'api'},
    ]

     return(/**   <div>
           <h1 className= "text-center" >Audit Events</h1>
           <table className = "table table-striped">
              <thead>
                  <tr>
                      <td>Transaction Id</td>
                      <td>Entity Name</td>
                      <td>Method Name</td>
                  </tr>
              </thead>   
              <tbody>
                {
                  this.state.events.map( event => 
                  <tr key = {event.id}>
                      <td>{event.transactionCode}</td>
                      <td>{event.entityName}</td>
                      <td>{event.methodName}</td>
                  </tr>
                  )
                }
              </tbody>   
              </table>
       </div>**/
      
       <div>
            <h3>Audit Events</h3>
           <MaterialTable title="Audit Logs"
               data={this.state.events}
               columns={column}
               options={{
              // rowStyle:'style of func',
               paging:true,
              // filtering:true,
               exportButton:true}} />
           </div>)
    }
}

export default AuditComponent;