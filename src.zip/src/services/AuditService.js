import axios from 'axios'

const AUDIT_API = "http://localhost:8905/auditEvents/show";

class AuditService {
    getAuditEvents() {
        return axios.get(AUDIT_API);
    }
}

export default new AuditService();
