import logo from './logo.svg';
import './App.css';
import AuditComponent from './components/AuditComponent';
import DataTableRowExpansionDemo from './components/Audit_trail';
import Sidebar from './components/Sidemenu';

function App() {
  return (
    <div className="App"> 
      <div>
       <DataTableRowExpansionDemo/>
     </div>
     <div>
      <Sidebar/>
     </div>
     </div>
  );
}

export default App;
